create table employee
(
id integer not null;
firstname varchar(250) not null;
lastname varchar(250) not null;
primary key(id)
);




insert into employee(id, name, last_name) 
values(100,'gopi','gosika');
insert into employee (id, name, last_name) 
values(101,'priyanka' ,'pinky' );
insert into employee(id, name, last_name ) 
values(102,'chaitu', 'chinnu');



















